# Link-Archiv

Ein Karteikasten für gespeicherte Links: Name, Thema, Favoriten, Suche und Sortierung –
mit gemeinsamer, dauerhafter Speicherung, die du mit anderen teilen kannst.

## Einrichtung auf GitHub Pages (kostenlos, dauerhaft)

1. Lege ein neues **öffentliches** Repository auf GitHub an (z. B. `link-archiv`).
2. Lade beide Dateien aus diesem Ordner (`index.html`, `README.md`) in das Repository hoch
   (per Drag & Drop auf der GitHub-Weboberfläche unter "Add file" → "Upload files").
3. Gehe im Repository zu **Settings → Pages**.
4. Wähle unter "Source" den Branch `main` (oder `master`) und Ordner `/ (root)`, dann **Save**.
5. Nach ein bis zwei Minuten ist die Seite erreichbar unter:
   `https://<dein-github-benutzername>.github.io/<repository-name>/`

Diese Adresse ist deine dauerhafte, öffentliche App – die kannst du dir merken, mit anderen
teilen und jederzeit im Browser öffnen.

## Benutzung

- Beim ersten Öffnen: **"Neues Archiv erstellen"** klicken, um einen eigenen, leeren
  Speicherplatz anzulegen. Dein Browser merkt sich die Archiv-ID danach automatisch.
- Über den Button **"Teilen"** (oben rechts) kopierst du einen Link, der die Archiv-ID enthält.
  Schickst du diesen Link an andere Personen, landen sie direkt in deinem gemeinsamen Archiv.
- **"Aktualisieren"** holt manuell den neuesten Stand; die App synchronisiert zusätzlich alle
  20 Sekunden automatisch im Hintergrund.
- **"Archiv wechseln"** verlässt das aktuelle Archiv auf diesem Gerät (die Daten bleiben online
  erhalten, du kannst mit der ID jederzeit zurückkehren oder ein neues Archiv anlegen).

## Wie die Daten gespeichert werden

Die App nutzt **[jsonblob.com](https://jsonblob.com)**, einen kostenlosen, öffentlichen
JSON-Speicherdienst ohne Anmeldung. Das bedeutet:

- **Kein Login nötig** – jede Person mit der Archiv-ID kann lesen, hinzufügen, bearbeiten
  und löschen. Es gibt keine Zugriffskontrolle. Teile die Archiv-ID nur mit Personen, denen
  du vertraust.
- Der Dienst ist kostenlos und öffentlich, aber nicht von dir kontrolliert – theoretisch
  könnte er den Dienst einstellen oder Daten verlieren. Für wirklich wichtige Daten empfiehlt
  sich zusätzlich eine gelegentliche manuelle Sicherung (z. B. per Screenshot oder Copy&Paste
  der wichtigsten Links).

## Dateien in diesem Ordner

- `index.html` – die komplette App (HTML, CSS, JavaScript in einer Datei)
- `README.md` – diese Anleitung
